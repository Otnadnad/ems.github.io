<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- Site favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="vendors/images/ekg-favicon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="vendors/images/ekg-favicon.png">
    <link rel="icon" type="image/png" sizes="16x16" href="vendors/images/ekg-favicon.png">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- CSS -->
    <link rel="stylesheet" type="text/css" href="vendors/styles/core.css">
    <link rel="stylesheet" type="text/css" href="vendors/styles/icon-font.min.css">
    <link rel="stylesheet" type="text/css" href="src/plugins/jquery-steps/jquery.steps.css">
    <link rel="stylesheet" type="text/css" href="src/plugins/datatables/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" type="text/css" href="src/plugins/datatables/css/responsive.bootstrap4.min.css">
    <link rel="stylesheet" type="text/css" href="vendors/styles/style.css">

    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css"
      integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />

    <script src="vendors/scripts/core.js"></script>
    <script src="vendors/scripts/script.min.js"></script>
    <script src="vendors/scripts/process.js"></script>
    <script src="vendors/scripts/layout-settings.js"></script>
    <script src="src/plugins/apexcharts/apexcharts.min.js"></script>
    <script src="src/plugins/datatables/js/jquery.dataTables.min.js"></script>
    <script src="src/plugins/datatables/js/dataTables.bootstrap4.min.js"></script>
    <script src="src/plugins/datatables/js/dataTables.responsive.min.js"></script>
    <script src="src/plugins/datatables/js/responsive.bootstrap4.min.js"></script>
    <script src="vendors/scripts/datagraph.js"></script>

    <!-- buttons for Export datatable -->
    <script src="src/plugins/datatables/js/dataTables.buttons.min.js"></script>
    <script src="src/plugins/datatables/js/buttons.bootstrap4.min.js"></script>
    <script src="src/plugins/datatables/js/buttons.print.min.js"></script>
    <script src="src/plugins/datatables/js/buttons.html5.min.js"></script>
    <script src="src/plugins/datatables/js/buttons.flash.min.js"></script>
    <script src="src/plugins/datatables/js/pdfmake.min.js"></script>
    <script src="src/plugins/datatables/js/vfs_fonts.js"></script>
    
    <script src="vendors/scripts/advanced-components.js"></script>

    <!-- JS for QRCODE -->
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/webrtc-adapter/3.3.3/adapter.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/vue/2.1.10/vue.min.js"></script>
	<script type="text/javascript" src="https://rawgit.com/schmich/instascan-builds/master/instascan.min.js"></script>

    <link rel="stylesheet" href="scannerincludes/style.css" />
    <title>QR Code Generator - Scanner</title>
  </head>
  <body>
    <div class="header">
      <div class="row">
        <div class="col-sm-12">
          <div class="input-group mb-0">
              <a href="index.php"><input class="btn btn-primary btn-lg btn-block" name="signin" id="signin" type="submit" value="Back" style="background-color: #8b0000"></a>
          </div>
        </div>
      </div>
    </div>
    <div class="wrapper">
      <h1 style="text-align: center; color: #8B0000">SCAN QR-CODE</h1>
      <div class="container" id="scanner-container" style="display: flex; justify-content: center;">
        <div class="left">
          <p class="heading">QR Code</p>
          <label for="file" class="dropzone">
            <div class="content show">
              <video id="camera-preview" style="width: 100%; height: 100%; object-fit: cover;"></video>
            </div>
          </label>
          
          <form action="scannerincludes/insert.php" method="POST">
                  <span class="number" style="display: flex; justify-content: center; padding: 3% 0;"><input type="text" name="text" id="text" readonly="" placeholder="scan-qrcode" class="scanned"></span>
          </form>
        </div>
        
        <div class="card-box mb-30" style="width: 100%;">
          <div class="pd-20">
              <h2 class="text-blue h4">ALL Employee Attendances</h2>
          </div>

          <div class="pb-20">
            <table class="data-table table stripe hover nowrap">
              <thead>
                <!-- for no sort table data = class="table-plus datatable-nosort" -->
                <tr>
                  <th>ID</th>
                  <!-- <th class="table-plus datatable-nosort">STAFF QRCODE</th> -->
                  <th class="table-plus datatable-nosort">STAFF NAME</th>
                  <th>TIME IN</th>
                  <th>TIME OUT</th>
                  <th>LOGDATE</th>
                  <!-- <th>REG. STATUS</th> -->
                  <!-- <th class="datatable-nosort">ACTION</th> -->
                </tr>
              </thead>
              <tbody>
                <?php include('includes/config.php')?>
                  <?php
                    $sql = "SELECT id, qrcodedata, name, timein, timeout, logdate, status FROM attendance";
                    $query = $conn->query($sql);
                    while($row = $query->fetch_assoc()){
                  ?>
                  <tr>
                    
                      <td><?php echo $row['id']; ?></td>
                      <!-- <td><?php echo $row['qrcodedata']; ?></td> -->
                      <td><?php echo $row['name']; ?></td>
                      <!-- <td><?php echo base64_encode($row['name']); ?></td> -->
                      <!-- <td>
                        <?php
                          $encryption_key = "my secret key";
                          $iv = "my fixed iv1234\0";
                          $encrypted_name = openssl_encrypt($row['name'], 'AES-256-CBC', $encryption_key, OPENSSL_RAW_DATA, $iv);
                          $partial_decrypted_name = substr($encrypted_name, 0, 3) . "..." . substr($encrypted_name, -3);
                          echo $partial_decrypted_name;
                        ?>
                      </td> -->

                      <td><?php echo $row['timein']; ?></td>
                      <td><?php echo $row['timeout']; ?></td>
                      <td><?php echo $row['logdate']; ?></td>
                      <!-- <td><?php echo $row['status']; ?></td> -->
                      
                  </tr>
                  <?php
                    }
                  ?>
              </tbody>
            </table>
          </div>
        </div>

      </div>
      
    </div>
    
     
    <!-- Include MD5JS library -->
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/blueimp-md5/2.18.0/js/md5.min.js"></script> -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/3.1.2/rollups/aes.js" integrity="sha256-/H4YS+7aYb9kJ5OKhFYPUjSJdrtV6AeyJOtTkw6X72o=" crossorigin="anonymous"></script>
    <!-- JS for the camera -->
    <script src="heads/decryptencrypt.js"></script>
    <script>
        let scanner = new Instascan.Scanner({ video: document.getElementById('camera-preview')});
        Instascan.Camera.getCameras().then(function(cameras){
            if (cameras.length > 0) {
                scanner.start(cameras[0]);
            } else {
                alert('Camera Not Found');	
            }
        }).catch(function(e){
            console.error(e);
        });

        scanner.addListener('scan',function(c){
            document.getElementById('text').value=c;
            document.forms[0].submit();
        });
    </script>
    
  
    <!-- JavaScript code -->
    <!-- <script type="text/javascript">
      let scanner = new Instascan.Scanner({ video: document.getElementById('camera-preview')});
      Instascan.Camera.getCameras().then(function(cameras){
          if (cameras.length > 0) {
              scanner.start(cameras[0]);
          } else {
              alert('Camera Not Found');	
          }
      }).catch(function(e){
          console.error(e);
      });

      scanner.addListener('scan', function(qrcodedata){
          // Decrypt the QR code data using CryptoJS
          let decryptedData = CryptoJS.AES.decrypt(qrcodedata, "my-secret-key").toString(CryptoJS.enc.Utf8);

          if (decryptedData) {
              // Set the value of the "text" input tag to the decrypted data
              document.getElementById('text').value = decryptedData;
              
              // Set the value of the "name" input tag to the decrypted data
              document.getElementById('name-input').value = decryptedData;
              
              // Submit the form
              document.forms[0].submit();
          } else {
              alert('Unable to decrypt QR code');
          }
      });
    </script>  -->

    <!-- for alert message of the scanner -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    
    <!-- JS for the alerts -->
    <?php
    if (isset($_SESSION['success']) && $_SESSION['success'] !='') {
        ?>
        <script>
            swal({
                title: "<?php echo $_SESSION['success'];?>",
                text: "<?php echo $_SESSION['note'];?>",
                icon: "success",
                button: "Okay Done",
                timer: 2000
            });
        </script>
        <?php
            unset($_SESSION['success']);
        }			
        ?>

    <?php
        if (isset($_SESSION['error']) && $_SESSION['error'] !='') {
            ?>
            <script>
                swal({
                    title: "<?php echo $_SESSION['error'];?>",
                    text: "<?php echo $_SESSION['note'];?>",
                    icon: "error",
                    button: "Okay Done",
                    timer: 2000
                });
            </script>
            <?php
                unset($_SESSION['error']);
            }			
            ?>
        
  </body>
</html>
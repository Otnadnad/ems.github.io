<?php
    // // Set the backup folder path
    $backupFolder = "../database/";

    // Set the database connection details
    $host = "localhost"; // Replace with your database host
    $username = "root"; // Replace with your database username
    $password = ""; // Replace with your database password
    $database = "ems";

    // Create a connection to the database
    $conn = mysqli_connect($host, $username, $password, $database);

    // Get a list of all tables in the database
    $tables = array();
    $result = mysqli_query($conn, "SHOW TABLES");
    while ($row = mysqli_fetch_row($result)) {
        $tables[] = $row[0];
    }

    // Loop through each table and create a backup file for it
    foreach ($tables as $table) {
        $filename = $backupFolder . $table . ".sql"; // Add the backup folder path to the filename
        $handle = fopen($filename, "w");
        fwrite($handle, "DROP TABLE IF EXISTS `$table`;\n");
        $result = mysqli_query($conn, "SHOW CREATE TABLE `$table`");
        $row = mysqli_fetch_row($result);
        fwrite($handle, $row[1] . ";\n");
        $result = mysqli_query($conn, "SELECT * FROM `$table`");
        while ($row = mysqli_fetch_assoc($result)) {
            $sql = "INSERT INTO `$table` (";
            foreach ($row as $key => $value) {
                $sql .= "`$key`, ";
            }
            $sql = rtrim($sql, ", ") . ") VALUES (";
            foreach ($row as $value) {
                $sql .= "'" . mysqli_real_escape_string($conn, $value) . "', ";
            }
            $sql = rtrim($sql, ", ") . ");\n";
            fwrite($handle, $sql);
        }
        fclose($handle);
    }

    // Close the database connection
    mysqli_close($conn);

    // echo "Backup process completed successfully!";
    $alertMessage = "Backup process completed successfully!";
    echo "<script>alert('$alertMessage');</script>";
?>

<?php
    // // Set the backup folder path
    // $backupFolder = "../database/";

    // // Set the database connection details
    // $host = "localhost"; // Replace with your database host
    // $username = "root"; // Replace with your database username
    // $password = ""; // Replace with your database password
    // $database = "ems";

    // // Set the backup filename
    // $filename = $backupFolder . $database . "-" . date("Y-m-d-H-i-s") . ".sql";

    // // Build the mysqldump command
    // $command = "mysqldump -h $host -u $username -p$password $database > $filename";

    // // Execute the mysqldump command
    // system($command, $result);

    // if ($result === 0) {
    //     // echo "Backup process completed successfully!";
    //     $alertMessage = "Backup process completed successfully!";
    //     echo "<script>alert('$alertMessage');</script>";
    // } else {
    //     // echo "Backup process failed with error code $result.";
    //     $alertMessage = "Backup process failed with error code $result.";
    //     echo "<script>alert('$alertMessage');</script>";
    // }
?>

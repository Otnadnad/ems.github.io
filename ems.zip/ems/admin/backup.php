<?php include('includes/header.php')?>
<?php include('../includes/session.php')?>
<style>
    button {
    display: inline-block;
    border-radius: 4px;
    background-color: #3d405b;
    border: none;
    color: #FFFFFF;
    text-align: center;
    font-size: 17px;
    padding: 16px;
    width: 230px;
    transition: all 0.5s;
    cursor: pointer;
    margin: 5px;
    }

    button span {
    cursor: pointer;
    display: inline-block;
    position: relative;
    transition: 0.5s;
    }

    button span:after {
    content: '»';
    position: absolute;
    opacity: 0;
    top: 0;
    right: -15px;
    transition: 0.5s;
    }

    button:hover span {
    padding-right: 15px;
    }

    button:hover span:after {
    opacity: 1;
    right: 0;
    }
</style>

<body>
	<!-- <div class="pre-loader">
		<div class="pre-loader-box">
			<div class="loader-logo"><img src="../vendors/images/ekgs.png" alt=""></div>
			<div class='loader-progress' id="progress_div">
				<div class='bar' id='bar1'></div>
			</div>
			<div class='percent' id='percent1'>0%</div>
			<div class="loading-text">
				Loading...
			</div>
		</div>
	</div> -->

	<?php include('includes/navbar.php')?>

	<?php include('includes/right_sidebar.php')?>

	<?php include('includes/left_sidebar.php')?>

	<div class="mobile-menu-overlay"></div>

	<div class="main-container">
		<div class="pd-ltr-20">
			<div class="card-box pd-20 height-100-p mb-30">
				<div class="row align-items-center">
					<div class="col-md-4 user-icon">
						<!-- <img src="../vendors/images/banner-img.png" alt=""> -->
                        <img src="../vendors/images/cooking.png" alt="" style="width: 243px">
					</div>
					<div class="col-md-8">

						<?php $query= mysqli_query($conn,"select * from tblemployees where emp_id = '$session_id'")or die(mysqli_error());
								$row = mysqli_fetch_array($query);
						?>

						<h4 class="font-20 weight-500 mb-10 text-capitalize">
							Welcome back <div class="weight-600 font-30 text-blue"><?php echo $row['FirstName']. " " .$row['LastName']; ?>,</div>
						</h4>
						<p class="font-18 max-width-600">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Tenetur, cumque?</p>
					</div>
				</div>
			</div>
			<div class="title pb-20">
				<h2 class="h3 mb-0">Data Information</h2><br>
                <button id="backup-restore-btn" onclick="backupDatabase()">
                    <span>Backup Database</span>
                </button>
			</div>
           

            <!-- <script>
                function backupDatabase() {
                    // Send a request to the server to initiate the backup process
                    var xhr = new XMLHttpRequest();
                    xhr.open('GET', 'backups.php');
                    xhr.send();

                    // Show a message to the user indicating that the backup process has started
                    alert('Backup process has started.');

                    // Reload the page after a delay to allow time for the backup to complete
                    setTimeout(function() {
                        location.reload();
                    }, 5000);
                }
            </script> -->
            
            <script>
                function backupDatabase() {
                    // Send a request to the server to initiate the backup process
                    var xhr = new XMLHttpRequest();
                    xhr.open('GET', 'backups.php');
                    xhr.send();

                    // Show a message to the user indicating that the backup process has started
                    alert('Backup process has started.');

                    // Check the status of the request after it has completed
                    xhr.onload = function() {
                        if (xhr.status === 200) {
                            // The request was successful, so show a message indicating that the backup process has completed successfully
                            alert('Backup process completed successfully!');
                        } else {
                            // The request failed, so show an error message
                            alert('Backup process failed with error code ' + xhr.status + '.');
                        }

                        // Reload the page after a delay to allow time for the message to be displayed
                        setTimeout(function() {
                            location.reload();
                        }, 5000);
                    };
                }
            </script>


            
		
			<?php include('includes/footer.php'); ?>
		</div>
	</div>
	<!-- js -->

	<?php include('includes/scripts.php')?>
</body>
</html>
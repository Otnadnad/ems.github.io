<?php 
include('../../includes/config.php');
include ('PHPMailer.php');
include ('Exception.php');
include ('SMTP.php');
?>
<?php
// APP PASSWORD GMAIL : aobgsukbpfjxbosb


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

$mail = new PHPMailer();
$mail->isSMTP();
$mail->Host = "smtp.gmail.com";
$mail->SMTPAuth = true;
$mail->SMTPSecure = "tls";
$mail->Port = "587";

$mail->Username = "enkichie@gmail.com";
$mail->Password = "aobgsukbpfjxbosb";

$mail->Subject = "User Account:";

$mail->setFrom('enkichie@gmail.com');

$mail->isHTML(true);
$mail->Body = "<h2>En Kichie Garage - EMS</h2></br><p>Your account is: $email and and your temporary password is: $password</p><br><p>Please change your password immediately</p>";

$mail->addAddress($email);

if ( $mail->send() ) {
	echo 	"<script type = 'text/javascript'>
			alert ('Email sent successfully to $email');
			window.location.href = 'staff.php';
			</script>";
}else{
	echo 	"<script type = 'text/javascript'>
			alert ('Failed while sending code!');
			window.location.href = 'add_staff.php';
			</script>";
}

$mail->smtpClose();
?>
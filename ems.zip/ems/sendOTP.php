<?php require_once "controllerUserData.php"; ?>
<?php
// APP PASSWORD GMAIL : aobgsukbpfjxbosb


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

$mail = new PHPMailer();
$mail->isSMTP();
$mail->Host = "smtp.gmail.com";
$mail->SMTPAuth = true;
$mail->SMTPSecure = "tls";
$mail->Port = "587";

$mail->Username = "enkichie@gmail.com";
$mail->Password = "aobgsukbpfjxbosb";

$mail->Subject = "Password Reset Code:";

$mail->setFrom('enkichie@gmail.com');

$mail->isHTML(true);
$mail->Body = "<h2>En Kichie Garage - EMS</h2></br><p>Your password reset code is: $code</p>";

$mail->addAddress($email);

if ( $mail->send() ) {
	echo 	"<script type = 'text/javascript'>
			alert ('Email sent successfully to $email');
			window.location.href = 'reset-code.php';
			</script>";
}else{
	echo 	"<script type = 'text/javascript'>
			alert ('Failed while sending code!');
			window.location.href = 'forgotpassword.php';
			</script>";
}

$mail->smtpClose();
?>
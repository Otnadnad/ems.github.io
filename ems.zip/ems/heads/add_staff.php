<?php include('includes/header.php')?>
<?php include('../includes/session.php')?>
<?php
	if (isset($_POST['add_staff'])) {
		$qrcode = $_FILES['qrcode']['tmp_name'];
		$filename = basename($_FILES['qrcode']['name']);

		move_uploaded_file($qrcode, "../src/qrcode/" . $filename);

		$qrcodedata = $_POST['qrcodedata'];
		$fname = $_POST['firstname'];
		$lname = $_POST['lastname'];
		$email = $_POST['email'];
		$password = $_POST['password'];
		$hashpwd = md5($password);
		$gender = $_POST['gender'];
		$dob = $_POST['dob'];
		$department = $_POST['department'];
		$address = $_POST['address'];
		$leave_days = $_POST['leave_days'];
		$user_role = $_POST['user_role'];
		$phonenumber = $_POST['phonenumber'];
		$status = 1;

		$existingDataQuery = mysqli_query($conn, "SELECT * FROM tblemployees WHERE qrcodedata = '$qrcodedata'") or die(mysqli_error());
		$countExistingData = mysqli_num_rows($existingDataQuery);

		if ($countExistingData > 0) {
			?>
			<script>
				alert('Qr-Code Already Exists');
			</script>
			<?php
		} else {
			$query = mysqli_query($conn, "SELECT * FROM tblemployees WHERE EmailId = '$email'") or die(mysqli_error());
			$count = mysqli_num_rows($query);

			if ($count > 0) {
				?>
				<script>
					alert('Data Already Exists');
				</script>
				<?php
			} else {
				mysqli_query($conn, "INSERT INTO tblemployees(qrcode, qrcodedata, FirstName, LastName, EmailId, Password, Gender, Dob, Department, Address, Av_leave, role, Phonenumber, Status, location) 
				VALUES('$filename', '$qrcodedata', '$fname', '$lname', '$email', '$hashpwd', '$gender', '$dob', '$department', '$address', '$leave_days', '$user_role', '$phonenumber', '$status', 'NO-IMAGE-AVAILABLE.jpg')") or die(mysqli_error());

				// Include PHPMailer/sendEmail.php file
				include 'PHPMailer/sendEmail.php';
				?>
				<script>
					alert('Staff Records Successfully Added');
					window.location = "staff.php";
				</script>
				<?php
			}
		}
	}
?>

<!-- <?php
	if(isset($_POST['add_staff']))
	{
		if(isset($_FILES['qrcode']) && is_uploaded_file($_FILES['qrcode']['tmp_name']) && isset($_FILES['qrcode']['name'])) {
			$qrcode=$_FILES['qrcode']['name'];
			$qrcodedata=$_POST['qrcodedata'];
			$fname=$_POST['firstname'];
			$lname=$_POST['lastname'];
			$email=$_POST['email'];
			$password=md5($_POST['password']);
			$gender=$_POST['gender'];
			$dob=$_POST['dob'];
			$department=$_POST['department'];
			$address=$_POST['address'];
			$leave_days=$_POST['leave_days'];
			$user_role=$_POST['user_role'];
			$phonenumber=$_POST['phonenumber'];
			$status=1;
	
			move_uploaded_file($_FILES['qrcode']['tmp_name'], '../src/qrcode/'.$qrcode);
	
			$query = mysqli_query($conn,"select * from tblemployees where EmailId = '$email'")or die(mysqli_error());
			$count = mysqli_num_rows($query);
	
			if ($count > 0){ ?>
				<script>
					alert('Data Already Exist');
				</script>
			<?php } else {
				mysqli_query($conn,"INSERT INTO tblemployees(qrcode,qrcodedata,FirstName,LastName,EmailId,Password,Gender,Dob,Department,Address,Av_leave,role,Phonenumber,Status, location) VALUES('$qrcode','$qrcodedata','$fname','$lname','$email','$password','$gender','$dob','$department','$address','$leave_days','$user_role','$phonenumber','$status', 'NO-IMAGE-AVAILABLE.jpg')") or die(mysqli_error()); ?>
				<script>alert('Staff Records Successfully  Added');</script>;
				<script>window.location = "staff.php"; </script>
			<?php }
		} else {
			echo "<script>alert('Please Select Picture to Update');</script>";
		}
	}	
?> -->


<!-- style for generate button -->
<style>
	button {
	position: relative;
	display: inline-block;
	cursor: pointer;
	outline: none;
	border: 0;
	vertical-align: middle;
	text-decoration: none;
	background: transparent;
	padding: 0;
	font-size: inherit;
	font-family: inherit;
	}

	button.learn-more {
	width: 12rem;
	height: auto;
	}

	button.learn-more .circle {
	transition: all 0.45s cubic-bezier(0.65, 0, 0.076, 1);
	position: relative;
	display: block;
	margin: 0;
	width: 3rem;
	height: 3rem;
	background: #282936;
	border-radius: 1.625rem;
	}

	button.learn-more .circle .icon {
	transition: all 0.45s cubic-bezier(0.65, 0, 0.076, 1);
	position: absolute;
	top: 0;
	bottom: 0;
	margin: auto;
	background: #fff;
	}

	button.learn-more .circle .icon.arrow {
	transition: all 0.45s cubic-bezier(0.65, 0, 0.076, 1);
	left: 0.625rem;
	width: 1.125rem;
	height: 0.125rem;
	background: none;
	}

	button.learn-more .circle .icon.arrow::before {
	position: absolute;
	content: "";
	top: -0.29rem;
	right: 0.0625rem;
	width: 0.625rem;
	height: 0.625rem;
	border-top: 0.125rem solid #fff;
	border-right: 0.125rem solid #fff;
	transform: rotate(45deg);
	}

	button.learn-more .button-text {
	transition: all 0.45s cubic-bezier(0.65, 0, 0.076, 1);
	position: absolute;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	padding: 0.75rem 0;
	margin: 0 0 0 1.85rem;
	color: #282936;
	font-weight: 700;
	line-height: 1.6;
	text-align: center;
	text-transform: uppercase;
	}

	button:hover .circle {
	width: 100%;
	}

	button:hover .circle .icon.arrow {
	background: #fff;
	transform: translate(1rem, 0);
	}

	button:hover .button-text {
	color: #fff;
	}
</style>

<body>
	<!-- <div class="pre-loader">
		<div class="pre-loader-box">
			<div class="loader-logo"><img src="../vendors/images/ekgs.png" alt=""></div>
			<div class='loader-progress' id="progress_div">
				<div class='bar' id='bar1'></div>
			</div>
			<div class='percent' id='percent1'>0%</div>
			<div class="loading-text">
				Loading...
			</div>
		</div>
	</div> -->

	<?php include('includes/navbar.php')?>

	<?php include('includes/right_sidebar.php')?>

	<?php include('includes/left_sidebar.php')?>

	<div class="mobile-menu-overlay"></div>

	<div class="mobile-menu-overlay"></div>

	<div class="main-container">
		<div class="pd-ltr-20 xs-pd-20-10">
			<div class="min-height-200px">
				<div class="page-header">
					<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>Staff Portal</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation" class="navqr">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php" class="qrmodal" style="background-color: #fff; border: none;">Dashboard</a></li>
									<li class="breadcrumb-item active" aria-current="page">Staff Module</li>
								</ol>
							</nav>
						</div>
					</div>
				</div>

				<div class="pd-20 card-box mb-30">
					<div class="clearfix">
						<div class="pull-left" style="width: 100%; display:flex; justify-content: space-between;">
							<h4 class="text-blue h4">Staff Form</h4>
							<div class="wrapper_a">
								<button class="learn-more" onclick="proceedToPage()">
									<span class="circle" aria-hidden="true">
									<span class="icon arrow"></span>
									</span>
									<span class="button-text">Generate QR</span>
								</button>
								<!-- <a href="qrcodegenerator.php">Generate QR-Code</a> -->
							</div>
							<!-- script for qrcodegenerator -->
							<script>
								function proceedToPage() {
									window.location.href = "qrcodegenerator.php";
									}
							</script>
							
							<div id="demo-modal" class="modal">
								<div class="modal__content">
									<h1>QR-CODE GENERATOR</h1>

									<div class="wrapper">
										<div class="container active" id="generator-container">
											<div class="left">
											<form action="#">
												<div class="text">
												<label for="text">
													<i class="fa-solid fa-keyboard"></i>
													enter your Text or URL
												</label>
												<input
													type="text"
													id="text"
													placeholder="example (www.google.com) "
												/>
												</div>
												<div class="color">
												<label>
													<i class="fa-solid fa-paintbrush"></i>
													color
												</label>
												<div class="colors-wrapper">
													<div class="foreground">
													<span class="heading">foreground</span>
													<div class="custom-picker">
														<span></span>
														<input type="text" disabled value="#5a4ca1" />
														<input
														class="color-picker"
														type="color"
														id="fg-color"
														value="#5a4ca1"
														/>
													</div>
													</div>
													<div class="background">
													<span class="heading">background</span>
													<div class="custom-picker">
														<span></span>
														<input type="text" disabled value="#ffffff" />
														<input
														class="color-picker"
														type="color"
														id="bg-color"
														value="#ffffff"
														/>
													</div>
													</div>
													<div class="corner">
													<span class="heading">corner</span>
													<div class="custom-picker">
														<span></span>
														<input type="text" disabled value="#000000" />
														<input
														class="color-picker"
														type="color"
														id="corner-color"
														value="#000000"
														/>
													</div>
													</div>
												</div>
												</div>
												<div class="type">
												<label>
													<i class="fa-solid fa-qrcode"></i>
													style
												</label>
												<div class="types-wrapper">
													<div class="dots">
													<span class="heading">dots</span>
													<div class="custom-dropdown">
														<span class="selected" id="dots-style">square</span>
														<i class="fa-solid fa-chevron-down"></i>
														<div class="options">
														<span class="option">dots</span>
														<span class="option active">square</span>
														<span class="option">rounded</span>
														<span class="option">extra-rounded</span>
														<span class="option">classy</span>
														<span class="option">classy-rounded</span>
														</div>
													</div>
													</div>
													<div class="corner-squares">
													<span class="heading">corners squares</span>
													<div class="custom-dropdown">
														<span class="selected" id="corner-squares-style"
														>square</span
														>
														<i class="fa-solid fa-chevron-down"></i>
														<div class="options">
														<span class="option">dots</span>
														<span class="option active">square</span>
														<span class="option">extra-rounded</span>
														</div>
													</div>
													</div>
													<div class="corner-dots">
													<span class="heading">corners dots</span>
													<div class="custom-dropdown">
														<span class="selected" id="corner-dots-style">square</span>
														<i class="fa-solid fa-chevron-down"></i>
														<div class="options">
														<span class="option">dots</span>
														<span class="option active">square</span>
														</div>
													</div>
													</div>
												</div>
												</div>

												<div class="logo">
												<label>
													<i class="fa-solid fa-image"></i>
													Logo
												</label>
												<div class="logos">
													<label class="logo">
													<input type="radio" name="logo" value="yt" checked />
													<img src="logos/youtube.png" alt="" id="yt" />
													</label>
													<label class="logo">
													<input type="radio" name="logo" value="fb"  />
													<img src="logos/facebook.png" alt="" id="fb" />
													</label>
													<label class="logo">
													<input type="radio" name="logo" value="tw" />
													<img src="logos/twitter.png" alt="" id="tw" />
													</label>
													<label class="logo">
													<input type="radio" name="logo" value="db" />
													<img src="logos/dribble.png" alt="" id="db" />
													</label>
													<label class="logo">
													<input type="radio" name="logo" value="li" />
													<img src="logos/linkedin.png" alt="" id="li" />
													</label>
													<label class="logo">
													<input type="radio" name="logo" value="ct" />
													<div class="upload-img">
														<i class="fa-solid fa-upload"></i>
														<input type="file" id="upload-img-input" />
														<img alt="" id="ct" />
													</div>
													</label>
												</div>
												</div>
												<div class="size">
												<label>
													<i class="fa-solid fa-expand"></i>
													size
												</label>
												<div class="custom-slider">
													<p class="left-text">low</p>
													<div class="slider">
													<span>500 x 500</span>
													<input
														type="range"
														min="100"
														max="2000"
														value="500"
														id="size"
													/>
													</div>
													<p class="right-text">high</p>
												</div>
												</div>
											</form>
											</div>
											<div class="right">
											<button class="generate-btn">generate qr code</button>
											<div class="qr-code">
												<div class="qr-code-img"></div>
											</div>
											<div class="download">
												<p>download in</p>
												<div class="download-btns">
												<button class="download-btn" id="download-png">
													<i class="fa-solid fa-download"></i>
													png
												</button>
												<button class="download-btn" id="download-jpg">
													<i class="fa-solid fa-download"></i>
													jpg
												</button>
												<button class="download-btn" id="download-svg">
													<i class="fa-solid fa-download"></i>
													svg
												</button>
												</div>
											</div>
											</div>
										</div>
										<div class="container" id="scanner-container">
											<div class="left">
											<p class="heading">QR Code</p>
											<label for="file" class="dropzone">
												<div class="content show">
												<span class="text">Drag QR Code here or</span>
												<button class="btn">browse</button>
												<input type="file" id="file" hidden />
												</div>
												<img id="preview" />
											</label>
											</div>
											<i class="fa-solid fa-arrow-right-arrow-left"></i>
											<div class="right">
											<div class="result">
												<p class="heading">Result</p>
												<textarea id="result" disabled></textarea>
												<div class="btns" id="result-btns">
												<button class="btn" id="copy">
													<i class="fa-solid fa-copy"></i>
													copy
												</button>
												<button class="btn" id="open">
													<i class="fa-solid fa-external-link"></i>
													open
												</button>
												</div>
											</div>
											</div>
										</div>
									</div>

									<script src="qr-code.js"></script>
									<script src="script.js"></script>
									<a href="#" class="modal__close">&times;</a>
								</div>
							</div>
						
							<!-- endpull-left class -->
						</div>
					</div>
					<div class="wizard-content">
						<form method="post" action="" enctype="multipart/form-data">
							<section>
								<div class="row">
									<div class="col-md-4 col-sm-12">
										<div class="form-group">
											<label >QRCODE :</label>
											<input name="qrcode" id="qrcode" type="file" class="form-control wizard-required" required="true" autocomplete="off">
										</div>
									</div>
									<script src="https://unpkg.com/@zxing/library@0.18.5"></script>
									
									<div class="col-md-4 col-sm-12">
										<div class="form-group">
											<label >Qr Code Data :</label>
											<input readonly name="qrcodedata" type="text" class="form-control wizard-required" required="true" autocomplete="off">
										</div>
									</div>
									<script>
										// Get a reference to the file input element and the QR code data input element
										const fileInput = document.querySelector('input[name="qrcode"]');
										const qrCodeDataInput = document.querySelector('input[name="qrcodedata"]');

										// Add an event listener to the file input element
										fileInput.addEventListener('change', async (event) => {
										// Get the selected file
										const file = event.target.files[0];

										// Create a new instance of the FileReader API
										const reader = new FileReader();

										// Add an event listener to the reader instance
										reader.addEventListener('load', async (event) => {
											// Get the data URL of the selected file
											const dataUrl = event.target.result;

											// Create a new instance of the BarcodeReader from the zxing-js library
											const barcodeReader = new ZXing.BrowserQRCodeReader();

											// Decode the QR code from the data URL
											const result = await barcodeReader.decodeFromImageUrl(dataUrl);

											// Set the value of the QR code data input element to the scanned QR code data
											qrCodeDataInput.value = result.text;
										});

										// Read the selected file as a data URL
										reader.readAsDataURL(file);
										});


									</script>
									<div class="col-md-4 col-sm-12">
										<div class="form-group">
											<label >First Name :</label>
											<input name="firstname" type="text" class="form-control wizard-required" required="true" autocomplete="off">
										</div>
									</div>
									<div class="col-md-4 col-sm-12">
										<div class="form-group">
											<label >Last Name :</label>
											<input name="lastname" type="text" class="form-control" required="true" autocomplete="off">
										</div>
									</div>
									<div class="col-md-4 col-sm-12">
										<div class="form-group">
											<label>Email Address :</label>
											<input name="email" type="email" class="form-control" required="true" autocomplete="off">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-4 col-sm-12">
										<div class="form-group">
											<label>Password :</label>
											<input name="password" type="password" placeholder="**********" class="form-control" required="true" autocomplete="off">
										</div>
									</div>
									<div class="col-md-4 col-sm-12">
										<div class="form-group">
											<label>Gender :</label>
											<select name="gender" class="custom-select form-control" required="true" autocomplete="off">
												<option value="">Select Gender</option>
												<option value="male">Male</option>
												<option value="female">Female</option>
											</select>
										</div>
									</div>
									<div class="col-md-4 col-sm-12">
										<div class="form-group">
											<label>Phone Number :</label>
											<input name="phonenumber" type="text" class="form-control" required="true" autocomplete="off">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-4 col-sm-12">
										<div class="form-group">
											<label>Date Of Birth :</label>
											<input name="dob" type="text" class="form-control date-picker" required="true" autocomplete="off">
										</div>
									</div>
									<div class="col-md-4 col-sm-12">
										<div class="form-group">
											<label>Address :</label>
											<input name="address" type="text" class="form-control" required="true" autocomplete="off">
										</div>
									</div>
									<div class="col-md-4 col-sm-12">
										<div class="form-group">
											<label>Department :</label>
											<select name="department" class="custom-select form-control" required="true" autocomplete="off">
												<!-- <option value="">Select Department</option>
													<?php
													$query = mysqli_query($conn,"select * from tbldepartments where DepartmentShortName = '$session_depart'");
													while($row = mysqli_fetch_array($query)){
													
													?>
													<option value="<?php echo $row['DepartmentShortName']; ?>"><?php echo $row['DepartmentName']; ?></option>
													<?php } ?> -->
													
													<option value="">Select Department</option>
													<?php
													$query = mysqli_query($conn,"select * from tbldepartments");
													while($row = mysqli_fetch_array($query)){
													
													?>
													<option value="<?php echo $row['DepartmentShortName']; ?>"><?php echo $row['DepartmentName']; ?></option>
													<?php } ?>
											</select>
										</div>
									</div>
								</div>

								<div class="row">
									<div class="col-md-4 col-sm-12">
										<div class="form-group">
											<label>Staff Leave Days :</label>
											<input name="leave_days" type="number" class="form-control" required="true" autocomplete="off">
										</div>
									</div>
									
									<div class="col-md-4 col-sm-12">
										<div class="form-group">
											<label>User Role :</label>
											<select name="user_role" class="custom-select form-control" required="true" autocomplete="off">
												<option value="">Select Role</option>
												<!-- <option value="Admin">Admin</option>
												<option value="HOD">HOD</option> -->
												<option value="Staff">Staff</option>
											</select>
										</div>
									</div>

									<div class="col-md-4 col-sm-12">
										
											<label style="font-size:16px;"><b></b></label>
											<div class="modal-footer justify-content-center">
												<button class="btn btn-primary" name="add_staff" id="add_staff" data-toggle="modal">Add&nbsp;Staff</button>
											</div>
										</div>
									</div>
								</div>
							</section>
						</form>
					</div>
				</div>

			</div>
			<?php include('includes/footer.php'); ?>
		</div>
	</div>
	<!-- js -->
	<?php include('includes/scripts.php')?>
</body>
</html>
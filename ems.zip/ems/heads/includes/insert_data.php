<?php
include('../includes/config.php');

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// // Retrieve data from the AJAX request
// $name = $_POST['name'];
// $timeFrom = $_POST['timeFrom'];
// $timeTo = $_POST['timeTo'];

// // Construct an SQL query
// $sql = "INSERT INTO schedule (name, timeFrom, timeTo) VALUES ('$name', '$timeFrom', '$timeTo')";

// // Execute the query
// if (mysqli_query($conn, $sql)) {
//     echo "success";
// } else {
//     echo "error";
// }

// // Close the connection
// mysqli_close($conn);


// Insert data into the database
if (isset($_POST['add_event'])) {
    $name = $_POST['name'];
    $timeFrom = $_POST['timeFrom'];
    $timeTo = $_POST['timeTo'];

    $sql = "INSERT INTO events (name, timeFrom, timeTo) VALUES ('$name', '$timeFrom', '$timeTo')";

    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}

// Close the database connection
mysqli_close($conn);
?>
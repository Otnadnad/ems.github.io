<?php include('includes/header.php')?>
<?php include('../includes/session.php')?>
<?php $get_id = $_GET['edit']; ?>


<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.1.1/crypto-js.min.js"></script> -->

<?php
	if(isset($_POST['editsched']))
	{
	// Retrieve the form data from the $_POST superglobal array
    $firstName = $_POST['FirstName'];
    $timeFromStr = $_POST['timeFrom'];
    $timeToStr = $_POST['timeTo'];
    $dateStr = $_POST['date'];
    
    // Convert the time format to H:i format
    $timeFrom = date("h:i A", strtotime($timeFromStr));
    $timeTo = date("h:i A", strtotime($timeToStr));

    // Create a DateTime object for the date and set the timezone to "Asia/Manila"
    $timezone = new DateTimeZone("Asia/Manila");
    $date = new DateTime($dateStr, $timezone);
    $date->setTime(0, 0, 0);


	$result = mysqli_query($conn,"update schedule set name='$firstName', timeFrom='$timeFrom', timeTo='$timeTo', date='{$date->format("F-j-Y")}' where id='$get_id'"); 		
	if ($result) {
     	echo "<script>alert('Schedule Successfully Updated');</script>";
     	echo "<script type='text/javascript'> document.location = 'schedule.php'; </script>";
	} else{
	  die(mysqli_error());
   }
		
}

?>


<body>
	<!-- <div class="pre-loader">
		<div class="pre-loader-box">
			<div class="loader-logo"><img src="../vendors/images/ekgs.png" alt=""></div>
			<div class='loader-progress' id="progress_div">
				<div class='bar' id='bar1'></div>
			</div>
			<div class='percent' id='percent1'>0%</div>
			<div class="loading-text">
				Loading...
			</div>
		</div>
	</div> -->

	<?php include('includes/navbar.php')?>

	<?php include('includes/right_sidebar.php')?>

	<?php include('includes/left_sidebar.php')?>

	<div class="mobile-menu-overlay"></div>

	<div class="mobile-menu-overlay"></div>

	<div class="main-container">
		<div class="pd-ltr-20 xs-pd-20-10">
			<div class="min-height-200px">
				<div class="page-header">
					<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>Schedule Portal</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
									<li class="breadcrumb-item active" aria-current="page">Schedule Edit</li>
								</ol>
							</nav>
						</div>
					</div>
				</div>

				<div class="pd-20 card-box mb-30">
					<div class="clearfix">
						<div class="pull-left" style="width: 100%; display: flex; justify-content: space-between;">
							<h4 class="text-blue h4">Edit Schedule</h4>
						<!-- endpull-left class -->
					</div>
					<div class="wizard-content">
						<form method="post" action="">
							<section>
								<?php
									$query = mysqli_query($conn,"SELECT * FROM schedule WHERE id = '$get_id' ")or die(mysqli_error());
									$row = mysqli_fetch_array($query);
									?>
								
								<div class="row">
									<div class="col-md-4 col-sm-12">
										<div class="form-group">
											<label >Name :</label>
											<input name="FirstName" type="text" class="form-control wizard-required" required="true" autocomplete="off" value="<?php echo $row['name']; ?>">
										</div>
									</div>
									
									
									<div class="col-md-4 col-sm-12">
										<div class="form-group">
											<label >Time From :</label>
											<input name="timeFrom" type="time" class="form-control wizard-required" required="true" autocomplete="off" value="<?php echo $row['timeFrom']; ?>">
										</div>
									</div>
									
									<div class="col-md-4 col-sm-12">
										<div class="form-group">
											<label >Time To :</label>
											<input name="timeTo" type="time" class="form-control wizard-required" required="true" autocomplete="off" value="<?php echo $row['timeTo']; ?>">
										</div>
									</div>
									<div class="col-md-4 col-sm-12">
										<div class="form-group">
											<label >Date:</label>
											<input name="date" type="date" timezone="Asia/Manila" class="form-control" required="true" autocomplete="off" value="<?php echo $row['date']; ?>">
										</div>
									</div>
									
								</div>

								<div class="row">
									<div class="col-md-4 col-sm-12">
										<div class="form-group">
											<label style="font-size:16px;"><b></b></label>
											<div class="modal-footer justify-content-center">
												<button class="btn btn-primary" name="editsched" id="add_staff" data-toggle="modal">Update&nbsp;Schedule</button>
											</div>
										</div>
									</div>
								</div>
							</section>
						</form>
					</div>
				</div>

			</div>
			<?php include('includes/footer.php'); ?>
		</div>
	</div>
	<!-- js -->
	<?php include('includes/scripts.php')?>
</body>
</html>
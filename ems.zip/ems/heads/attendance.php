<?php include('includes/header.php')?>
<?php include('../includes/session.php')?>

<body>
	<!-- <div class="pre-loader">
		<div class="pre-loader-box">
			<div class="loader-logo"><img src="../vendors/images/ekgs.png" alt=""></div>
			<div class='loader-progress' id="progress_div">
				<div class='bar' id='bar1'></div>
			</div>
			<div class='percent' id='percent1'>0%</div>
			<div class="loading-text">
				Loading...
			</div>
		</div>
	</div> -->

	<style>
		/*******VIDEO CAM CSS*****/
		.video-div{
			padding: 2% 2%;
			/* background-color: #0b3cc1; */
			width: 100%; 

		}
		.video-container {
			position: relative;
			/* background-color: #242526; */
			width: 50%;
			height: 0%;
			padding-bottom: 0%; /*4:3 aspect ratio*/
			border: 10px solid #f1f1f1;
			border-radius: 5px;
			overflow: hidden;
			box-shadow: 0px 0px 10px 0px #000;
		}
		/* Style for the video element */
		.video-container video {
			width: 100%;
			height: 100%;
		}

		/* CSS PLACEHOLDER OF SCANNED QRCODE */
		.scanned {
			background-color: #212121;
			max-width: 190px;
			height: 40px;
			padding: 10px;
			/* text-align: center; */
			border: 2px solid white;
			border-radius: 5px;
			/* box-shadow: 3px 3px 2px rgb(249, 255, 85); */
		}
		
		.scanned:focus {
			color: rgb(0, 255, 255);
			background-color: #212121;
			outline-color: rgb(0, 255, 255);
			box-shadow: -3px -3px 15px rgb(0, 255, 255);
			transition: .1s;
			transition-property: box-shadow;
		}
	</style>

	<?php include('includes/navbar.php')?>

	<?php include('includes/right_sidebar.php')?>

	<?php include('includes/left_sidebar.php')?>

	<div class="mobile-menu-overlay"></div>

	<div class="main-container">
		<div class="pd-ltr-20">
			<div class="page-header">
				<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>Attendances</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php" style="background-color: #fff; border: none;">Dashboard</a></li>
									<li class="breadcrumb-item active" aria-current="page">All Attendance</li>
								</ol>
							</nav>
						</div>
				</div>
			</div>

			<div class="card-box mb-30">
				<div class="pd-20">
						<h2 class="text-blue h4">ALL Employee Attendances</h2>
				</div>

				<div class="pb-20">
					<table class="data-table table stripe hover nowrap">
						<thead>
							<!-- for no sort table data = class="table-plus datatable-nosort" -->
							<tr>
								<th>ID</th>
								<!-- <th class="table-plus datatable-nosort">STAFF QRCODE</th> -->
								<th class="table-plus datatable-nosort">STAFF NAME</th>
								<th>TIME IN</th>
								<th>TIME OUT</th>
								<th>LOGDATE</th>
								<!-- <th>REG. STATUS</th> -->
								<!-- <th class="datatable-nosort">ACTION</th> -->
							</tr>
						</thead>
						<tbody>
							
							
                            <?php
                                $sql = "SELECT id, qrcodedata, name, timein, timeout, logdate, status FROM attendance";
                                $query = $conn->query($sql);
                                while($row = $query->fetch_assoc()){
                                ?>
                                <tr>
                                    <td><?php echo $row['id']; ?></td>
									<!-- <td><?php echo $row['qrcodedata']; ?></td> -->
                                    <td><?php echo $row['name']; ?></td>
                                    <td><?php echo $row['timein']; ?></td>
                                    <td><?php echo $row['timeout']; ?></td>
                                    <td><?php echo $row['logdate']; ?></td>
                                    <!-- <td><?php echo $row['status']; ?></td> -->
                                    
                                </tr>
                                <?php
                                }
                                ?>
						</tbody>
					</table>
			   </div>
			</div>

			<!-- AUTO REFRESH: -->
			<!-- <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
			<script>
				$(document).ready(function() {
					setInterval(function() {
						$('#loader').load(location.href + ' #loader');
					}, 2000); // refresh table every 5 seconds
				});
			</script> -->


			<?php include('includes/footer.php'); ?>
		</div>
	</div>
	<!-- js -->

	<script src="../vendors/scripts/core.js"></script>
	<script src="../vendors/scripts/script.min.js"></script>
	<script src="../vendors/scripts/process.js"></script>
	<script src="../vendors/scripts/layout-settings.js"></script>
	<script src="../src/plugins/apexcharts/apexcharts.min.js"></script>
	<script src="../src/plugins/datatables/js/jquery.dataTables.min.js"></script>
	<script src="../src/plugins/datatables/js/dataTables.bootstrap4.min.js"></script>
	<script src="../src/plugins/datatables/js/dataTables.responsive.min.js"></script>
	<script src="../src/plugins/datatables/js/responsive.bootstrap4.min.js"></script>
    


	<!-- buttons for Export datatable -->
	<script src="../src/plugins/datatables/js/dataTables.buttons.min.js"></script>
	<script src="../src/plugins/datatables/js/buttons.bootstrap4.min.js"></script>
	<script src="../src/plugins/datatables/js/buttons.print.min.js"></script>
	<script src="../src/plugins/datatables/js/buttons.html5.min.js"></script>
	<script src="../src/plugins/datatables/js/buttons.flash.min.js"></script>
	<script src="../src/plugins/datatables/js/vfs_fonts.js"></script>
	
	<script src="../vendors/scripts/datatable-setting.js"></script></body>
</body>
</html>
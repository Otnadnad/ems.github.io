<?php


if (isset($_POST['image_src']) && isset($_POST['image_name'])) {
    $imageSrc = $_POST['image_src'];
    $imageName = $_POST['image_name'];
    $imageData = base64_decode(str_replace('data:image/png;base64,', '', $imageSrc));
    $filePath = 'src/qrcode/' . $imageName;
    if (file_put_contents($filePath, $imageData)) {
        echo 'Image downloaded successfully';
    } else {
        echo 'Error downloading image';
    }
}
?>

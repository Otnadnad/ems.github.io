<?php
    session_start();
    include ('../includes/config.php');

    if (isset($_POST['addsched'])) {
        // Retrieve the form data from the $_POST superglobal array
        $firstName = $_POST['FirstName'];
        $timeFromStr = $_POST['timeFrom'];
        $timeToStr = $_POST['timeTo'];
        $dateStr = $_POST['date'];

        // Convert the time format to H:i format
        $timeFrom = date("h:i A", strtotime($timeFromStr));
        $timeTo = date("h:i A", strtotime($timeToStr));

        // Create a DateTime object for the date and set the timezone to "Asia/Manila"
        $timezone = new DateTimeZone("Asia/Manila");
        $date = new DateTime($dateStr, $timezone);
        $date->setTime(0, 0, 0);

        // Insert the data into the database
        $sql = "INSERT INTO schedule (name, timeFrom, timeTo, date) VALUES ('$firstName', '$timeFrom', '$timeTo', '{$date->format("F-j-Y")}')";

        if (mysqli_query($conn, $sql)) {
            $_SESSION['success'] = 'Successfully Added';
            $_SESSION['note'] = 'Schedule Added';
        } else {
            $_SESSION['error'] = $conn->error;
        }
        header("location: schedule.php");
        mysqli_close($conn);
    }
?>

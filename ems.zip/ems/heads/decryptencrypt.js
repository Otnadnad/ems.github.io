  
      const wrapper = document.querySelector(".wrapper"),
      qrInput = wrapper.querySelector(".form input"),
      generateBtn = wrapper.querySelector(".form button"),
      qrImg = wrapper.querySelector(".qr-code img");
      let preValue;

      generateBtn.addEventListener("click", () => {
          let qrValue = qrInput.value.trim();
          if(!qrValue || preValue === qrValue) return;
          preValue = qrValue;
          generateBtn.innerText = "Generating QR Code...";
           // Encrypt the data using MD5 hash function
              // const sha256 = new Hashes.SHA256();
              // const hashedData = sha256.hex(qrValue);

          // let hashedData = md5(qrValue);
          var encrypted = CryptoJS.AES.encrypt(qrValue, "Secret Key");
        //   var decrypted = CryptoJS.AES.decrypt(encrypted, "Secret Key");
        //   console.log(decrypted.toString(CryptoJS.enc.Utf8));

          qrImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encrypted}`;
          qrImg.addEventListener("load", () => {
              wrapper.classList.add("active");
              generateBtn.innerText = "Generate QR Code";
          });
      });



      qrInput.addEventListener("keyup", () => {
          if(!qrInput.value.trim()) {
              wrapper.classList.remove("active");
              preValue = "";
          }
      });

      



      
   
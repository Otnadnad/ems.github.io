<!-- <!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css"
      integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
    <link rel="stylesheet" href="includes/styleadd.css" />
    <title>QR Code Generator - Scanner</title>
  </head>
  <style>
    a.back {
    background-color: #f7f7f7;
    border: 1px solid #ddd;
    color: #444;
    display: inline-block;
    padding: 8px 16px;
    text-decoration: none;
    border-radius: 4px;
    }

    a.back:hover {
    background-color: #ddd;
    }

  </style>
  <body>
    <div class="wrapper">
    <a href="javascript:history.back()">Back</a>
      <nav>
        <a href="index.html">QR Code</a>
        <div class="active" id="generator">Generator</div>
        <div id="scanner">Scanner</div>
      </nav>
      
      <div class="container active" id="generator-container">
        <div class="left">
          <form action="#">
            <div class="text">
              <label for="text">
                <i class="fa-solid fa-keyboard"></i>
                enter your Text or URL
              </label>
              <input
                type="text"
                id="text"
                placeholder="example (www.google.com) "
              />
            </div>
            <div class="color">
              <label>
                <i class="fa-solid fa-paintbrush"></i>
                color
              </label>
              <div class="colors-wrapper">
                <div class="foreground">
                  <span class="heading">foreground</span>
                  <div class="custom-picker">
                    <span></span>
                    <input type="text" disabled value="#5a4ca1" />
                    <input
                      class="color-picker"
                      type="color"
                      id="fg-color"
                      value="#5a4ca1"
                    />
                  </div>
                </div>
                <div class="background">
                  <span class="heading">background</span>
                  <div class="custom-picker">
                    <span></span>
                    <input type="text" disabled value="#ffffff" />
                    <input
                      class="color-picker"
                      type="color"
                      id="bg-color"
                      value="#ffffff"
                    />
                  </div>
                </div>
                <div class="corner">
                  <span class="heading">corner</span>
                  <div class="custom-picker">
                    <span></span>
                    <input type="text" disabled value="#000000" />
                    <input
                      class="color-picker"
                      type="color"
                      id="corner-color"
                      value="#000000"
                    />
                  </div>
                </div>
              </div>
            </div>
            <div class="type">
              <label>
                <i class="fa-solid fa-qrcode"></i>
                style
              </label>
              <div class="types-wrapper">
                <div class="dots">
                  <span class="heading">dots</span>
                  <div class="custom-dropdown">
                    <span class="selected" id="dots-style">square</span>
                    <i class="fa-solid fa-chevron-down"></i>
                    <div class="options">
                      <span class="option">dots</span>
                      <span class="option active">square</span>
                      <span class="option">rounded</span>
                      <span class="option">extra-rounded</span>
                      <span class="option">classy</span>
                      <span class="option">classy-rounded</span>
                    </div>
                  </div>
                </div>
                <div class="corner-squares">
                  <span class="heading">corners squares</span>
                  <div class="custom-dropdown">
                    <span class="selected" id="corner-squares-style"
                      >square</span
                    >
                    <i class="fa-solid fa-chevron-down"></i>
                    <div class="options">
                      <span class="option">dots</span>
                      <span class="option active">square</span>
                      <span class="option">extra-rounded</span>
                    </div>
                  </div>
                </div>
                <div class="corner-dots">
                  <span class="heading">corners dots</span>
                  <div class="custom-dropdown">
                    <span class="selected" id="corner-dots-style">square</span>
                    <i class="fa-solid fa-chevron-down"></i>
                    <div class="options">
                      <span class="option">dots</span>
                      <span class="option active">square</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="logo">
              <label>
                <i class="fa-solid fa-image"></i>
                Logo
              </label>
              <div class="logos">
                <label class="logo">
                  <input type="radio" name="logo" value="yt" checked />
                  <img src="logos/youtube.png" alt="" id="yt" />
                </label>
                <label class="logo">
                  <input type="radio" name="logo" value="fb"  />
                  <img src="logos/facebook.png" alt="" id="fb" />
                </label>
                <label class="logo">
                  <input type="radio" name="logo" value="tw" />
                  <img src="logos/twitter.png" alt="" id="tw" />
                </label>
                <label class="logo">
                  <input type="radio" name="logo" value="db" />
                  <img src="logos/dribble.png" alt="" id="db" />
                </label>
                <label class="logo">
                  <input type="radio" name="logo" value="li" />
                  <img src="logos/linkedin.png" alt="" id="li" />
                </label>
                <label class="logo">
                  <input type="radio" name="logo" value="ct" />
                  <div class="upload-img">
                    <i class="fa-solid fa-upload"></i>
                    <input type="file" id="upload-img-input" />
                    <img alt="" id="ct" />
                  </div>
                </label>
              </div>
            </div>
            <div class="size">
              <label>
                <i class="fa-solid fa-expand"></i>
                size
              </label>
              <div class="custom-slider">
                <p class="left-text">low</p>
                <div class="slider">
                  <span>500 x 500</span>
                  <input
                    type="range"
                    min="100"
                    max="2000"
                    value="500"
                    id="size"
                  />
                </div>
                <p class="right-text">high</p>
              </div>
            </div>
          </form>
        </div>
        <div class="right">
          <button class="generate-btn">generate qr code</button>
          <div class="qr-code">
            <div class="qr-code-img"></div>
          </div>
          <div class="download">
            <p>download in</p>
            <div class="download-btns">
              <button class="download-btn" id="download-png" onclick="downloadFile('png')">
                <i class="fa-solid fa-download"></i>
                png
              </button>
              <button class="download-btn" id="download-jpg" onclick="downloadFile('jpg')">
                <i class="fa-solid fa-download"></i>
                jpg
              </button>
              <button class="download-btn" id="download-svg" onclick="downloadFile('svg')">
                <i class="fa-solid fa-download"></i>
                svg
              </button>
            </div>
          </div>
        </div>
      </div>
      <div class="container" id="scanner-container">
        <div class="left">
          <p class="heading">QR Code</p>
          <label for="file" class="dropzone">
            <div class="content show">
              <span class="text">Drag QR Code here or</span>
              <button class="btn">browse</button>
              <input type="file" id="file" hidden />
            </div>
            <img id="preview" />
          </label>
        </div>
        <i class="fa-solid fa-arrow-right-arrow-left"></i>
        <div class="right">
          <div class="result">
            <p class="heading">Result</p>
            <textarea id="result" disabled></textarea>
            <div class="btns" id="result-btns">
              <button class="btn" id="copy">
                <i class="fa-solid fa-copy"></i>
                copy
              </button>
              <button class="btn" id="open">
                <i class="fa-solid fa-external-link"></i>
                open
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <script src="qr-code.js"></script>
    <script src="script.js"></script>
    <script>
        var close = document.getElementsByClassName('close')[0];

        close.onclick = function() {
        modal.style.display = 'none';
        }

    </script>
    
    <script>
      function downloadFile(format) {
        // Get the canvas element
        var canvas = document.getElementById('canvas');
        // Get the download link
        var downloadLink = document.createElement('a');
        // Set the file name
        downloadLink.download = 'myimage.' + format;
        // Convert the canvas to a data URL
        var dataURL = canvas.toDataURL('image/' + format);
        // Set the data URL as the download link href
        downloadLink.href = dataURL;
        // Trigger the download
        downloadLink.click();

        // Specify the folder path where the file will be saved
        var folderPath = 'C:/xampp/htdocs/ems/src/qrcode'; // Replace with your folder path

        // Create an XMLHttpRequest to read the file as a blob
        var xhr = new XMLHttpRequest();
        xhr.open('GET', downloadLink.href, true);
        xhr.responseType = 'blob';
        xhr.onload = function(e) {
          if (this.status == 200) {
            // Create a new file object
            var file = new File([this.response], downloadLink.download);
            // Create a new FileReader
            var reader = new FileReader();
            reader.onload = function() {
              // Create a new XMLHttpRequest to save the file
              var xhrSave = new XMLHttpRequest();
              xhrSave.open('PUT', folderPath + '/' + downloadLink.download, true);
              xhrSave.onload = function() {
                if (this.status == 200) {
                  console.log('File saved successfully');
                } else {
                  console.error('Error saving file');
                }
              };
              xhrSave.send(reader.result);
            };
            reader.readAsArrayBuffer(file);
          }
        };
        xhr.send();
      }
    </script>
  </body>
</html> -->

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">  
    <title>QR Code Generator</title>
    <link rel="stylesheet" href="includes/styleqr.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  </head>
  <style>
    button {
      display: flex;
      height: 3em;
      width: 100px;
      align-items: center;
      justify-content: center;
      background-color: #eeeeee4b;
      border-radius: 3px;
      letter-spacing: 1px;
      transition: all 0.2s linear;
      cursor: pointer;
      border: none;
      background: #fff;
      }

      button > svg {
      margin-right: 5px;
      margin-left: 5px;
      font-size: 20px;
      transition: all 0.4s ease-in;
      }

      button:hover > svg {
      color: #fff;
      font-size: 1.2em;
      transform: translateX(-5px);
      }

      button:hover {
      color: #fff;
      background-color: #8B0000;
      box-shadow: 9px 9px 33px #d1d1d1, -9px -9px 33px #ffffff;
      transform: translateY(-2px);
      }
  </style>
  <body>
    
    <div class="wrapper">
      <button onclick="goBack()">
        <svg height="16" width="16" xmlns="http://www.w3.org/2000/svg" version="1.1" viewBox="0 0 1024 1024"><path d="M874.690416 495.52477c0 11.2973-9.168824 20.466124-20.466124 20.466124l-604.773963 0 188.083679 188.083679c7.992021 7.992021 7.992021 20.947078 0 28.939099-4.001127 3.990894-9.240455 5.996574-14.46955 5.996574-5.239328 0-10.478655-1.995447-14.479783-5.996574l-223.00912-223.00912c-3.837398-3.837398-5.996574-9.046027-5.996574-14.46955 0-5.433756 2.159176-10.632151 5.996574-14.46955l223.019353-223.029586c7.992021-7.992021 20.957311-7.992021 28.949332 0 7.992021 8.002254 7.992021 20.957311 0 28.949332l-188.073446 188.073446 604.753497 0C865.521592 475.058646 874.690416 484.217237 874.690416 495.52477z"></path></svg>
        <span>Back</span>
      </button>
      <!-- script for back button -->
      <script>
        function goBack() {
          window.history.back();
        }
      </script>
      <!-- <div class="back"><a href="javascript:history.back()">Back</a></div> -->

      <header>
        <h1>QR Code Generator</h1>
        <p>Enter your Employee ID</p>
      </header>
      
      <div class="form">
        <input type="text" spellcheck="false" placeholder="Employee ID" required maxlength="11">
        <button onclick="generateQRCode()">Generate QR Code</button>
      </div>
      <script>
        const inputField = document.querySelector('input');
        
        inputField.addEventListener('input', (event) => {
          const userInput = event.target.value;
          event.target.value = `ID - ${userInput.replace(/^ID - /, '')}`;
        });
      </script>
      <form action="" method="POST">
        <div class="qr-code">
          <img src="" id="myImage" alt="qr-code">
        </div>
        <div class="footer" style="padding-top: 10px;">
          <button type="button" name="upload"  onclick="saveQRCode()">Download</button>
        </div>
      </form>
      
    </div>


<!-- 
    <script src="https://cdnjs.cloudflare.com/ajax/libs/blueimp-md5/2.18.0/js/md5.min.js"></script> -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/3.1.2/rollups/aes.js" integrity="sha256-/H4YS+7aYb9kJ5OKhFYPUjSJdrtV6AeyJOtTkw6X72o=" crossorigin="anonymous"></script>
    <script src="decryptencrypt.js"></script>
    <!-- <script>
      const wrapper = document.querySelector(".wrapper"),
      qrInput = wrapper.querySelector(".form input"),
      generateBtn = wrapper.querySelector(".form button"),
      qrImg = wrapper.querySelector(".qr-code img");
      let preValue;

      generateBtn.addEventListener("click", () => {
        let qrValue = qrInput.value.trim();
        if(!qrValue || preValue === qrValue) return;
        preValue = qrValue;
        generateBtn.innerText = "Generating QR Code...";
        
        // Encrypt the data using SHA-256 hash function
        const sha256 = new Hashes.SHA256();
        const hashedData = sha256.hex(qrValue);
        
        // Generate the QR code using the hashed data
        qrImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${hashedData}`;
        qrImg.addEventListener("load", () => {
          wrapper.classList.add("active");
          generateBtn.innerText = "Generate QR Code";
        });
      });

      qrInput.addEventListener("keyup", () => {
        if(!qrInput.value.trim()) {
          wrapper.classList.remove("active");
          preValue = "";
        }
      });
  </script> -->

    <!-- <script>
      const wrapper = document.querySelector(".wrapper"),
      qrInput = wrapper.querySelector(".form input"),
      generateBtn = wrapper.querySelector(".form button"),
      qrImg = wrapper.querySelector(".qr-code img");
      let preValue;

      generateBtn.addEventListener("click", () => {
        let qrValue = qrInput.value.trim();
        if(!qrValue || preValue === qrValue) return;
        preValue = qrValue;
        generateBtn.innerText = "Generating QR Code...";
        
        // Encrypt the data using SHA-256 hash function
        const sha256 = new Hashes.SHA256();
        const hashedData = sha256.hex(qrValue);
        
        // Generate the QR code using the hashed data
        qrImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${hashedData}`;
        qrImg.addEventListener("load", () => {
          wrapper.classList.add("active");
          generateBtn.innerText = "Generate QR Code";
        });
      });

      qrInput.addEventListener("keyup", () => {
        if(!qrInput.value.trim()) {
          wrapper.classList.remove("active");
          preValue = "";
        }
      });
    </script> -->

    <script>
      function generateQRCode() {
        // Generate QR Code and display in the img tag
        var qrCodeUrl = "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=da";
        document.getElementById("myImage").src = qrCodeUrl;
      }

      function saveQRCode() {
        // Get the image URL and filename
        var imageUrl = document.getElementById("myImage").src;
        var fileName = "qrcode.png";

        // Create an anchor element with the download attribute
        var link = document.createElement("a");
        link.download = fileName;
        link.href = imageUrl;

        // Trigger a click event on the anchor element to start download
        link.click();
      }
    </script>

    <!-- <script>
      function generateQRCode() {
          // Generate QR Code and display in the img tag
          var qrCodeUrl = "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=da";
          document.getElementById("myImage").src = qrCodeUrl;
      }

      // Submit the form to download the image
      document.querySelector('form').addEventListener('submit', function (e) {
          e.preventDefault();
          var imageSrc = document.getElementById("myImage").src;
          var imageName = "qrcode.png";
          downloadImage(imageSrc, imageName);
      });

      // Function to download the image using PHP
      function downloadImage(imageSrc, imageName) {
          var xhr = new XMLHttpRequest();
          xhr.open("POST", "download.php", true);
          xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
          xhr.onreadystatechange = function() {
              if (xhr.readyState === 4 && xhr.status === 200) {
                  console.log(xhr.responseText);
              }
          };
          xhr.send("image_src=" + imageSrc + "&image_name=" + imageName);
      }

    </script> -->



    <!-- <script>
      const downloadBtn = wrapper.querySelector(".download-btn");

      downloadBtn.addEventListener("click", () => {
        const qrCodeUrl = qrImg.src;
        const fileName = `qrcode_${Date.now()}.png`;

        const link = document.createElement("a");
        link.href = qrCodeUrl;
        link.download = fileName;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      });

    </script> -->
  </body>
</html>
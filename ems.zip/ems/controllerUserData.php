<?php
session_start();
include('includes/config.php');
include ('PHPMailer.php');
include ('Exception.php');
include ('SMTP.php');
$email = "";
$name = "";
$errors = array();

//if user click continue button in forgot password form
if(isset($_POST['check-email'])){
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $check_email = "SELECT * FROM tblemployees WHERE EmailId='$email'";
    $run_sql = mysqli_query($conn, $check_email);
    if(mysqli_num_rows($run_sql) > 0){
        $code = rand(999999, 111111);
        $insert_code = "UPDATE tblemployees SET code = $code WHERE EmailId = '$email'";
        $run_query =  mysqli_query($conn, $insert_code);
        if($run_query){
            include 'sendOTP.php';
            // $info = "We've sent a passwrod reset otp to your email - $email";
            // $_SESSION['info'] = $info;
            // $_SESSION['email'] = $email;
    
        }else{
            $errors['db-error'] = "Something went wrong!";
        }
    }else{
        $errors['EmailId'] = "This email address does not exist!";
    }
}

//if user click verification code submit button
// if(isset($_POST['check'])){
//     $_SESSION['info'] = "";
//     $otp_code = mysqli_real_escape_string($conn, $_POST['otp']);
//     $check_code = "SELECT * FROM tblemployees WHERE code = $otp_code";
//     $code_res = mysqli_query($conn, $check_code);
//     if(mysqli_num_rows($code_res) > 0){
//         $fetch_data = mysqli_fetch_assoc($code_res);
//         $fetch_code = $fetch_data['code'];
//         $email = $fetch_data['EmailId'];
//         $code = 0;
//         $stats = 'verified';
//         $update_otp = "UPDATE tblemployees SET code = $code, stats = '$stats' WHERE code = $fetch_code";
//         $update_res = mysqli_query($conn, $update_otp);
//         if($update_res){
//             $_SESSION['FirstName'] = $name;
//             $_SESSION['EmailId'] = $email;
//             header('location: new-password.php');
//             exit();
//         }else{
//             $errors['otp-error'] = "Failed while updating code!";
//         }
//     }else{
//         $errors['otp-error'] = "You've entered incorrect code!";
//     }
// }



//if user click check reset otp button
if(isset($_POST['check-reset-otp'])){
    $_SESSION['info'] = "";
    $otp_code = mysqli_real_escape_string($conn, $_POST['otp']);
    $check_code = "SELECT * FROM tblemployees WHERE code = $otp_code";
    $code_res = mysqli_query($conn, $check_code);
    if(mysqli_num_rows($code_res) > 0){
        $fetch_data = mysqli_fetch_assoc($code_res);
        $email = $fetch_data['EmailId'];
        $_SESSION['EmailId'] = $email;
        $info = "Please create a new password that you don't use on any other site.";
        $_SESSION['info'] = $info;
        header('location: new-password.php');
        exit();
    }else{
        $errors['otp-error'] = "You've entered incorrect code!";
    }
}

//if user click change password button
if(isset($_POST['change-password'])){
    $_SESSION['info'] = "";
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $cpassword = mysqli_real_escape_string($conn, $_POST['cpassword']);
    if($password !== $cpassword){
        $errors['password'] = "Confirm password not matched!";
    }else{
        $code = 0;
        $email = $_SESSION['EmailId']; //getting this email using session
        $encpass = md5($password);
        $update_pass = "UPDATE tblemployees SET code = $code, Password = '$encpass' WHERE EmailId = '$email'";
        $run_query = mysqli_query($conn, $update_pass);
        if($run_query){
            $info = "Your password changed. Now you can login with your new password.";
            $_SESSION['info'] = $info;
            header('Location: password-changed.php');
        }else{
            $errors['db-error'] = "Failed to change your password!";
        }
    }
}


?>
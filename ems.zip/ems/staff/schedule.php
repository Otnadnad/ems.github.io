<?php include('includes/header.php')?>
<?php include('../includes/session.php')?>

<!-- style for add sched button -->
<link rel="stylesheet" href="includes/styleschedmodal.css">
<body>
	<!-- <div class="pre-loader">
		<div class="pre-loader-box">
			<div class="loader-logo"><img src="../vendors/images/ekgs.png" alt=""></div>
			<div class='loader-progress' id="progress_div">
				<div class='bar' id='bar1'></div>
			</div>
			<div class='percent' id='percent1'>0%</div>
			<div class="loading-text">
				Loading...
			</div>
		</div>
	</div> -->

	<?php include('includes/navbar.php')?>

	<?php include('includes/right_sidebar.php')?>

	<?php include('includes/left_sidebar.php')?>

	<div class="mobile-menu-overlay"></div>

	<div class="main-container">
		<div class="pd-ltr-20">
			<div class="page-header">
				<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>Schedule</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
									<li class="breadcrumb-item active" aria-current="page">All Schedules</li>
								</ol>
							</nav>
						</div>
				</div>
			</div>

			<div class="card-box mb-30">
				<div class="pd-20" style="width: 100%; display:flex; justify-content: space-between;">
                    <h2 class="text-blue h4">ALL Employee Schedules</h2>
				</div>

                <div class="pb-20">
                <table class="data-table table stripe hover nowrap">
						<thead>
							<!-- for no sort table data = class="table-plus datatable-nosort" -->
							<tr>
								<th class="table-plus datatable-nosort">STAFF NAME</th>
								<th>TIME FROM</th>
								<th>TIME TO</th>
								<th>DATE</th>
							</tr>
						</thead>
						<tbody>
                            <?php
                            
                            ?>
							
                            <?php
                                $sql = "SELECT id, name, timeFrom, timeTo, date FROM schedule";
                                $query = $conn->query($sql);
                                while($row = $query->fetch_assoc()){
                                ?>
                                <tr>
                                    <!-- <td><?php echo $row['id']; ?></td> -->
                                    <td><?php echo $row['name']; ?></td>
                                    <td><?php echo $row['timeFrom']; ?></td>
                                    <td><?php echo $row['timeTo']; ?></td>
                                    <td><?php echo $row['date']; ?></td>
                                </tr>
                                <?php
                                }
                                ?>
						</tbody>
					</table>
                </div>
			</div>

			<?php include('includes/footer.php'); ?>
		</div>
	</div>

	<!-- js -->

	<script src="../vendors/scripts/core.js"></script>
	<script src="../vendors/scripts/script.min.js"></script>
	<script src="../vendors/scripts/process.js"></script>
	<script src="../vendors/scripts/layout-settings.js"></script>
	<script src="../src/plugins/apexcharts/apexcharts.min.js"></script>
	<script src="../src/plugins/datatables/js/jquery.dataTables.min.js"></script>
	<script src="../src/plugins/datatables/js/dataTables.bootstrap4.min.js"></script>
	<script src="../src/plugins/datatables/js/dataTables.responsive.min.js"></script>
	<script src="../src/plugins/datatables/js/responsive.bootstrap4.min.js"></script>

	<!-- buttons for Export datatable -->
	<script src="../src/plugins/datatables/js/dataTables.buttons.min.js"></script>
	<script src="../src/plugins/datatables/js/buttons.bootstrap4.min.js"></script>
	<script src="../src/plugins/datatables/js/buttons.print.min.js"></script>
	<script src="../src/plugins/datatables/js/buttons.html5.min.js"></script>
	<script src="../src/plugins/datatables/js/buttons.flash.min.js"></script>
	<script src="../src/plugins/datatables/js/vfs_fonts.js"></script>
	
	<script src="../vendors/scripts/datatable-setting.js"></script></body>
</body>
</html>
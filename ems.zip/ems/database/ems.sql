-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 04, 2023 at 06:36 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ems`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `updationDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `UserName`, `Password`, `updationDate`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '2020-11-03 05:55:30');

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `qrcodedata` varchar(250) NOT NULL,
  `name` varchar(255) NOT NULL,
  `timein` varchar(255) NOT NULL,
  `timeout` varchar(255) NOT NULL,
  `logdate` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`id`, `qrcodedata`, `name`, `timein`, `timeout`, `logdate`, `status`) VALUES
(1, '', 'Dan Mark', '03:24:44 AM', '03:28:46 AM', 'March-26-2023', '1'),
(2, '', 'John Mark', '03:30:16 AM', '03:33:14 AM', 'March-26-2023', '1'),
(3, '', 'Dan Mark', '12:46:49 AM', '02:02:59 AM', 'March-30-2023', '1'),
(4, '', 'John Mark', '12:52:54 AM', '01:21:53 AM', 'March-30-2023', '1'),
(5, '', 'Dan Mark', '12:56:41 AM', '02:02:59 AM', 'March-30-2023', '1'),
(6, '', 'John Mark', '01:06:42 AM', '01:21:53 AM', 'March-30-2023', '1'),
(7, '', 'Dan Mark', '01:16:40 AM', '02:02:59 AM', 'March-30-2023', '1'),
(8, '', 'John Mark', '01:20:11 AM', '01:21:53 AM', 'March-30-2023', '1'),
(9, '', 'Dan Mark', '01:45:47 AM', '02:02:59 AM', 'March-30-2023', '1'),
(10, '', 'Dan Mark', '02:05:14 AM', '', 'March-30-2023', '0'),
(11, '', 'Dan Mark', '11:30:34 PM', '11:31:19 PM', 'April-16-2023', '1'),
(12, '', 'Dan Mark', '12:08:48 AM', '07:49:57 PM', 'April-17-2023', '1'),
(13, '', 'John Mark', '12:08:57 AM', '08:17:45 PM', 'April-17-2023', '1'),
(14, '', 'John Mark', '12:11:46 AM', '08:17:45 PM', 'April-17-2023', '1'),
(15, '', 'Dan Mark', '12:55:51 PM', '07:49:57 PM', 'April-17-2023', '1'),
(16, '', 'Dan Mark', '02:03:33 PM', '07:49:57 PM', 'April-17-2023', '1'),
(17, '', 'https://l.ead.me/api-1', '02:29:09 PM', '', 'April-17-2023', '0'),
(18, '', 'John Mark', '03:10:52 PM', '08:17:45 PM', 'April-17-2023', '1'),
(19, '', 'DAN', '03:17:57 PM', '05:20:58 PM', 'April-17-2023', '1'),
(20, '', 'Dan Mark', '07:47:44 PM', '07:49:57 PM', 'April-17-2023', '1'),
(21, '', 'John Mark', '07:52:57 PM', '08:17:45 PM', 'April-17-2023', '1'),
(22, '', 'John Mark', '08:11:32 PM', '08:17:45 PM', 'April-17-2023', '1'),
(23, '', 'Jayne', '01:47:50 PM', '06:10:15 PM', 'April-19-2023', '1'),
(24, '', 'Dan Mark', '06:11:10 PM', '10:03:45 PM', 'April-19-2023', '1'),
(25, '', 'John Mark', '11:54:18 PM', '11:55:32 PM', 'April-19-2023', '1'),
(26, '', 'Dan Mark', '11:58:17 PM', '', 'April-19-2023', '0'),
(27, '', 'Dan Mark', '12:00:12 AM', '12:03:29 AM', 'April-20-2023', '1'),
(28, '', 'Dan Mark', '12:04:28 AM', '', 'April-20-2023', '0'),
(29, '', 'U2FsdGVkX1 DWb3 p2pTYxTUsOYIzMF18rmRy1ZY1zo=', '06:07:39 PM', '06:33:49 PM', 'April-20-2023', '1'),
(30, '', '', '06:23:40 PM', '', 'April-20-2023', '0'),
(31, '', '', '06:28:10 PM', '', 'April-20-2023', '0'),
(32, '', 'U2FsdGVkX19Q8T4GZju2uBUz7/RBv0yIvTe gnZKB/c=', '06:34:39 PM', '', 'April-20-2023', '0'),
(33, 'U2FsdGVkX19Q8T4GZju2uBUz7/RBv0yIvTe gnZKB/c=', '', '06:43:46 PM', '', 'April-20-2023', '0'),
(34, 'U2FsdGVkX19KtQjP/ctmzweHbkOLhbjU5SfMIS//IzY=', '', '07:47:22 PM', '', 'April-20-2023', '0'),
(35, 'U2FsdGVkX1 DWb3 p2pTYxTUsOYIzMF18rmRy1ZY1zo=', '', '07:54:18 PM', '', 'April-20-2023', '0'),
(36, 'U2FsdGVkX18GlWITvrGXrnehX m1BqTpEOll8aJx7aE=', '', '03:12:45 AM', '03:36:58 AM', 'April-21-2023', '1'),
(37, 'U2FsdGVkX18GlWITvrGXrnehX m1BqTpEOll8aJx7aE=', '', '03:21:36 AM', '03:36:58 AM', 'April-21-2023', '1'),
(38, 'U2FsdGVkX18GlWITvrGXrnehX m1BqTpEOll8aJx7aE=', '', '03:32:17 AM', '03:36:58 AM', 'April-21-2023', '1'),
(39, 'U2FsdGVkX18GlWITvrGXrnehX m1BqTpEOll8aJx7aE=', '', '03:35:09 AM', '03:36:58 AM', 'April-21-2023', '1'),
(40, 'U2FsdGVkX18GlWITvrGXrnehX m1BqTpEOll8aJx7aE=', '', '03:42:00 AM', '', 'April-21-2023', '0'),
(41, 'a95c4732c0bfad791af1f3849e404ea5', '', '05:52:50 AM', '05:53:05 AM', 'April-21-2023', '1'),
(42, 'U2FsdGVkX19DuBySUrG5 HeB6TxoYHTzmZYaR7DU/bI=', 'Dan Mark', '04:33:19 PM', '05:09:26 PM', 'April-21-2023', '1'),
(43, '8a2808b850d578d17131ea19a958cd7c', 'Bridget', '05:11:55 PM', '05:12:11 PM', 'April-21-2023', '1');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `timeFrom` varchar(255) NOT NULL,
  `timeTo` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`id`, `name`, `timeFrom`, `timeTo`, `date`) VALUES
(17, 'Bridget', '07:00 AM', '04:00 PM', 'April-23-2023'),
(18, 'Dan', '07:00 AM', '12:00 PM', 'April-22-2023'),
(19, 'Jayne', '08:00 AM', '05:00 PM', 'April-22-2023'),
(20, 'Paul', '08:00 AM', '02:00 PM', 'April-24-2023'),
(21, 'JM', '07:00 AM', '04:00 PM', 'April-25-2023');

-- --------------------------------------------------------

--
-- Table structure for table `tbldepartments`
--

CREATE TABLE `tbldepartments` (
  `id` int(11) NOT NULL,
  `DepartmentName` varchar(150) DEFAULT NULL,
  `DepartmentShortName` varchar(100) NOT NULL,
  `CreationDate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbldepartments`
--

INSERT INTO `tbldepartments` (`id`, `DepartmentName`, `DepartmentShortName`, `CreationDate`) VALUES
(2, 'Information Technologies', 'ICT', '2017-11-01 07:19:37'),
(3, 'Library', 'LIb', '2021-05-21 08:27:45'),
(4, 'Samgyup Resto', 'Samg', '2023-04-10 17:42:16'),
(6, 'Cofee Shop', 'CS', '2023-04-10 17:42:55');

-- --------------------------------------------------------

--
-- Table structure for table `tblemployees`
--

CREATE TABLE `tblemployees` (
  `emp_id` int(11) NOT NULL,
  `qrcode` varchar(500) NOT NULL,
  `qrcodedata` varchar(250) NOT NULL,
  `FirstName` varchar(150) NOT NULL,
  `LastName` varchar(150) NOT NULL,
  `EmailId` varchar(200) NOT NULL,
  `Password` varchar(180) NOT NULL,
  `Gender` varchar(100) NOT NULL,
  `Dob` varchar(100) NOT NULL,
  `Department` varchar(255) NOT NULL,
  `Address` varchar(255) NOT NULL,
  `Av_leave` varchar(150) NOT NULL,
  `Phonenumber` char(11) NOT NULL,
  `Status` int(1) NOT NULL,
  `RegDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `role` varchar(30) NOT NULL,
  `location` varchar(200) NOT NULL,
  `code` varchar(250) NOT NULL,
  `stats` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblemployees`
--

INSERT INTO `tblemployees` (`emp_id`, `qrcode`, `qrcodedata`, `FirstName`, `LastName`, `EmailId`, `Password`, `Gender`, `Dob`, `Department`, `Address`, `Av_leave`, `Phonenumber`, `Status`, `RegDate`, `role`, `location`, `code`, `stats`) VALUES
(1, 'janobe.png', 'U2FsdGVkX1/ecQxA/7Q5wysGhBHgpUaPeGBxFwrPCFE=', 'Janobe', 'Martins', 'janobe@janobe.com', '36d59e2369f00c4d9f336acf4408bae9', 'Male', '3 February, 1990', 'Samg', 'N NEPO', '30', '0248865955', 1, '2017-11-10 11:29:59', 'Staff', 'NO-IMAGE-AVAILABLE.jpg', '', ''),
(2, '', '', 'admin', 'admin', 'admin@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 'Male', '3 February, 1990', 'ICT', 'Binan', '30', '8587944255', 1, '2017-11-10 13:40:02', 'Admin', 'logo-black.png', '', ''),
(4, '', '', 'Nathaniel', 'Nkrumah', 'nat@gmail.com', 'b4cc344d25a2efe540adbf2678e2304c', 'Male', '3 February, 1990', 'ICT', 'N NEPO', '30', '587944255', 1, '2017-11-10 13:40:02', 'Admin', 'NO-IMAGE-AVAILABLE.jpg', '', ''),
(5, '', '', 'Owner', 'Owner', 'enkichie@gmail.com', '72122ce96bfec66e2396d2e25225d70a', 'Male', '3 February, 1990', 'ICT', 'dyan lang', '30', '587944255', 1, '2017-11-10 13:40:02', 'HOD', 'logo-white.png', '0', ''),
(7, 'bridget.png', 'U2FsdGVkX193N2dnZHfvBvvGw7Vc4OokKtLrFgwFRKU=', 'Bridget', 'Employee', 'employee@gmail.com', 'b4cc344d25a2efe540adbf2678e2304c', 'Female', '3 February, 1990', 'Samg', 'Binan', '30', '0596667981', 1, '2017-11-10 13:40:02', 'Staff', 'bridget.png', '', ''),
(8, '', '', 'Anna', 'Mensah', 'an@gmail.com', 'b4cc344d25a2efe540adbf2678e2304c', 'Female', '3 February, 1990', 'ICT', 'N NEPO', '30', '587944255', 1, '2017-11-10 13:40:02', 'HOD', 'NO-IMAGE-AVAILABLE.jpg', '', ''),
(10, 'Danqrcode.png', 'U2FsdGVkX18l4/gG WYpM/R9swRlFR00GLcGKhoaQOU=', 'Dan Mark', 'crvn', 'caravanadanmark@gmail.com', '0f281d173f0fdfdccccd7e5b8edc21f1', 'male', '09 April 2001', 'CS', 'binan laguna', '30', '09299716498', 1, '2023-03-26 09:20:53', 'Staff', 'NO-IMAGE-AVAILABLE.jpg', '312463', ''),
(11, 'JM.png', 'U2FsdGVkX1/4MkyA3MxvTmBFJHeStikQm5P oUp7wdg=', 'John Mark', 'Labto', 'jm@gmail.com', 'b4cc344d25a2efe540adbf2678e2304c', 'male', '16 May 2000', 'Samg', 'Langkiwa', '30', '09653294451', 1, '2023-04-17 10:21:46', 'Staff', 'NO-IMAGE-AVAILABLE.jpg', '', ''),
(12, 'jayne.png', 'U2FsdGVkX1/xs334E/76AwxPC9X2PvosmmNHaB7sap4=', 'Jayne', 'Arenas', 'jayne.arenas@gmail.com', '4eb8a566e4386589a98c4a13ccd12878', 'female', '20 February 2001', 'CS', '921 Pedro Escueta St. Brgy San Antonio Binan Laguna', '30', '09227956072', 1, '2023-04-17 16:28:44', 'Staff', 'NO-IMAGE-AVAILABLE.jpg', '0', ''),
(13, 'paul.png', 'U2FsdGVkX18tR0Ff1pLEqChvCg izM5HPflYRPLpGlw=', 'Jhun Paul', 'Bonaobra', 'jpaulbonaobra@gmail.com', '8ca4245f09e5a6ecf058c15cca9ac9b6', 'male', '09 August 1999', 'CS', 'Pragmatic', '30', '09653212541', 1, '2023-04-20 07:11:49', 'Staff', 'NO-IMAGE-AVAILABLE.jpg', '', ''),
(14, 'Nyomi.png', 'U2FsdGVkX1/0Wxx0sCkfsNVyDTNVW8Gp9l/rq eHBc4=', 'Neome Grace', 'Emperador', 'nyomi@gmail.com', 'abbc748ae5a105d711e4f2f3586fedd8', 'female', '22 December 2001', 'Samg', 'South City Homes Ilo-ilo Street Biñan Laguna', '30', '09456532124', 1, '2023-04-21 09:04:22', 'Staff', 'NO-IMAGE-AVAILABLE.jpg', '', ''),
(15, 'newqr.png', 'U2FsdGVkX18AySucBKSxkpn258qgVDXBFwi1fqJuKJI=', 'New', 'Emp', 'newemp@gmail.com', '719886a050e10c1a31db2518066c8820', 'male', '28 April 2000', 'Samg', 'Binan', '30', '09653256124', 1, '2023-04-28 06:33:36', 'Staff', 'NO-IMAGE-AVAILABLE.jpg', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tblleaves`
--

CREATE TABLE `tblleaves` (
  `id` int(11) NOT NULL,
  `LeaveType` varchar(110) NOT NULL,
  `ToDate` varchar(120) NOT NULL,
  `FromDate` varchar(120) NOT NULL,
  `Description` mediumtext NOT NULL,
  `PostingDate` date NOT NULL,
  `AdminRemark` mediumtext DEFAULT NULL,
  `registra_remarks` mediumtext NOT NULL,
  `AdminRemarkDate` varchar(120) DEFAULT NULL,
  `Status` int(1) NOT NULL,
  `admin_status` int(11) NOT NULL DEFAULT 0,
  `IsRead` int(1) NOT NULL,
  `empid` int(11) DEFAULT NULL,
  `num_days` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblleaves`
--

INSERT INTO `tblleaves` (`id`, `LeaveType`, `ToDate`, `FromDate`, `Description`, `PostingDate`, `AdminRemark`, `registra_remarks`, `AdminRemarkDate`, `Status`, `admin_status`, `IsRead`, `empid`, `num_days`) VALUES
(13, 'Casual Leave', '2021-05-02', '2021-05-12', 'I want to take a leave.', '2021-05-20', 'Ok', 'ok', '2021-05-24 20:26:19 ', 1, 1, 1, 7, 3),
(16, 'Casual Leave', '02-05-2021', '05-05-2021', 'Nice Leave', '2021-05-20', 'Ok', 'Noted', '2021-05-24 20:42:18 ', 1, 1, 1, 7, 4),
(17, 'Casual Leave', '11-05-2021', '15-05-2021', 'Just', '2021-05-21', 'Leave Approved', 'Noted', '2021-05-24 19:56:45 ', 1, 1, 1, 7, 5),
(18, 'Medical Leave', '27-03-2023', '28-03-2023', 'Medical Check-up', '2023-03-24', 'okay', 'k', '2023-03-25 13:25:57 ', 1, 1, 1, 7, 2),
(21, 'Medical Leave', '26-03-2023', '31-03-2023', 'check up', '2023-03-25', 'OKaay', '', '2023-03-25 14:32:46 ', 1, 0, 1, 7, 6),
(22, 'Vacation Leave', '25-04-2023', '28-04-2023', 'Need to take a break', '2023-04-10', 'Sure you can', '', '2023-04-10 23:26:49 ', 1, 0, 1, 7, 4),
(23, 'Vacation Leave', '20-04-2023', '30-04-2023', 'chill out', '2023-04-12', 'sorry', 'Leave was Rejected. Registra/Registry will not see it', '2023-04-12 11:44:30 ', 2, 2, 1, 7, 11),
(25, 'Medical Leave', '29-04-2023', '30-04-2023', 'Medical', '2023-04-28', 'okiks', '', '2023-04-28 13:14:28 ', 1, 0, 1, 10, 2),
(26, 'Vacation Leave', '29-04-2023', '31-05-2023', 'dawdad', '2023-04-28', 'too many days', 'Leave was Rejected. Registra/Registry will not see it', '2023-04-28 13:23:54 ', 2, 2, 1, 7, 33);

-- --------------------------------------------------------

--
-- Table structure for table `tblleavetype`
--

CREATE TABLE `tblleavetype` (
  `id` int(11) NOT NULL,
  `LeaveType` varchar(200) DEFAULT NULL,
  `Description` mediumtext DEFAULT NULL,
  `date_from` varchar(200) NOT NULL,
  `date_to` varchar(200) NOT NULL,
  `CreationDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblleavetype`
--

INSERT INTO `tblleavetype` (`id`, `LeaveType`, `Description`, `date_from`, `date_to`, `CreationDate`) VALUES
(5, 'Casual Leave', 'Casual Leaves', '2021-05-23', '2021-06-20', '2021-05-19 14:32:03'),
(6, 'Medical Leave', 'Medical Leave', '2021-05-05', '2021-05-28', '2021-05-19 15:29:05'),
(8, 'Other', 'Leave all staff', '31-05-2021', '04-06-2021', '2021-05-20 17:17:43'),
(10, 'Vacation Leave', 'Leave Vacation', '01-04-2023', '15-04-2023', '2023-04-10 17:53:34');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbldepartments`
--
ALTER TABLE `tbldepartments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblemployees`
--
ALTER TABLE `tblemployees`
  ADD PRIMARY KEY (`emp_id`);

--
-- Indexes for table `tblleaves`
--
ALTER TABLE `tblleaves`
  ADD PRIMARY KEY (`id`),
  ADD KEY `UserEmail` (`empid`);

--
-- Indexes for table `tblleavetype`
--
ALTER TABLE `tblleavetype`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tbldepartments`
--
ALTER TABLE `tbldepartments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tblemployees`
--
ALTER TABLE `tblemployees`
  MODIFY `emp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tblleaves`
--
ALTER TABLE `tblleaves`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `tblleavetype`
--
ALTER TABLE `tblleavetype`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

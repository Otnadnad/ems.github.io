<?php 
    // session_start();
    // include ('../includes/config.php');



    //     if (isset($_POST['text'])) {
    //         date_default_timezone_set('Asia/Manila');
    //         $name = $_POST['text'];
    //         $date = date('F-j-Y');
    //         $time = date('h:i:s A');

    //         // $sqlqr = "SELECT * FROM tblemployees WHERE qrcode";
    //         // $result = mysqli_query($conn, $sqlqr);

    //         if (mysqli_num_rows($result) > 0) {
    //             // QR code is valid
    //             $sql = "SELECT * FROM attendance WHERE name='$name' AND logdate='$date' AND status='0'";
    //             $query = $conn->query($sql);

    //             if ($query->num_rows > 0) {
    //                 $sql = "UPDATE attendance SET timeout = '$time', status='1' WHERE name='$name' AND logdate='$date'";

    //                 $query = $conn->query($sql);
    //                 $_SESSION['success'] = 'Successfully Time out';
    //                 $_SESSION['note'] = 'QR MATCH: Nice Work! Thank you';
    //             }
    //             else {
    //                 $sql = "INSERT INTO attendance (name, timein, logdate, status) VALUES('$name','$time','$date','0')";
    //                 if ($conn->query($sql) === TRUE) {
    //                     $_SESSION['success'] = 'Successfully Time in';
    //                     $_SESSION['note'] = 'QR MATCH: Break a leg!';
    //                 }
    //                 else {
    //                     $_SESSION['error'] = $conn->error;
    //                 }
    //             }
    //         } else {
    //             // QR code is invalid
    //             echo "QR code is invalid.";
    //         }

            
    //     }
    //     else {
    //         $_SESSION['error'] = 'Please Scan your QR CODE';
    //     }

    //     header("location: ../scanner.php");
    //     $conn-> close();
?>


<!-- OLD -->
<?php 
    // session_start();
    // include ('../includes/config.php');

    //     if (isset($_POST['text'])) {
    //         date_default_timezone_set('Asia/Manila');
    //         $name = $_POST['text'];
    //         $date = date('F-j-Y');
    //         $time = date('h:i:s A');


    //         $sql = "SELECT * FROM attendance WHERE name='$name' AND logdate='$date' AND status='0'";
    //         $query = $conn->query($sql);

    //         if ($query->num_rows > 0) {
    //             $sql = "UPDATE attendance SET timeout = '$time', status='1' WHERE name='$name' AND logdate='$date'";

    //             $query = $conn->query($sql);
    //             $_SESSION['success'] = 'Successfully Time out';
    //             $_SESSION['note'] = 'Nice Work! Thank you';
    //         }
    //         else {
    //             $sql = "INSERT INTO attendance (name, timein, logdate, status) VALUES('$name','$time','$date','0')";
    //             if ($conn->query($sql) === TRUE) {
    //                 $_SESSION['success'] = 'Successfully Time in';
    //                 $_SESSION['note'] = 'Break a leg!';
    //             }
    //             else {
    //                 $_SESSION['error'] = $conn->error;
    //             }
    //         }
    //     }
    //     else {
    //         $_SESSION['error'] = 'Please Scan your QR CODE';
    //     }

    //     header("location: ../scanner.php");
    //     $conn-> close();
?>

<!-- NEW -->
<?php
    session_start();
    include ('../includes/config.php');

    if (isset($_POST['text'])) {
        date_default_timezone_set('Asia/Manila');
        $qrcodedata = $_POST['text']; // this is encrypted
        $name = $_POST['name'];

        $date = date('F-j-Y');
        $time = date('h:i:s A');
    
        // Fetch the valid QR code data from the database

        // $sql = "SELECT qrcodedata FROM tblemployees WHERE qrcodedata='$qrcodedata'";

         // Fetch the valid QR code data and name from the database

        $sql = "SELECT qrcodedata, FirstName FROM tblemployees WHERE qrcodedata='$qrcodedata'";
        $query = $conn->query($sql);   
    
        if ($query->num_rows == 0) {
            $_SESSION['error'] = 'Invalid QR code';
            $_SESSION['note'] = 'QR Code Does not Match!';
            header("location: ../scanner.php");
            exit;
        }
    
        $row = $query->fetch_assoc();
        $valid_qr_code_data = $row['qrcodedata'];
        $employee_name = $row['FirstName'];
    
        // Get the scanned QR code data from the camera
        $scanned_qr_code_data = $_POST['text'];

    
        // Compare the valid QR code data to the scanned QR code data
        if ($valid_qr_code_data !== $scanned_qr_code_data) {
            $_SESSION['error'] = 'Invalid QR code';
            $_SESSION['note'] = 'Qr Code Does Not Match!';
            header("location: ../scanner.php");
            exit;
        }

        // Update the value of the name input tag with the fetched name
        echo '<script>document.getElementById("name-input").value = "'.$name.'";</script>';

        // Check if the individual has already timed in for the day
        $sql = "SELECT * FROM attendance WHERE qrcodedata='$qrcodedata' AND logdate='$date' AND status='0'";
        $query = $conn->query($sql);
    
        if ($query->num_rows > 0) {
            $sql = "UPDATE attendance SET timeout = '$time', status='1', name='$employee_name' WHERE qrcodedata='$qrcodedata' AND logdate='$date'";
    
            $query = $conn->query($sql);
            $_SESSION['success'] = 'Successfully Time out';
            $_SESSION['note'] = 'Nice Work! Thank you';
        }
        else {
            $sql = "INSERT INTO attendance (qrcodedata, name, timein, logdate, status) VALUES('$qrcodedata', '$employee_name', '$time','$date','0')";
            if ($conn->query($sql) === TRUE) {
                $_SESSION['success'] = 'Successfully Time in';
                $_SESSION['note'] = 'Break a leg!';
            }
            else {
                $_SESSION['error'] = $conn->error;
            }
        }
    }
    else {
        $_SESSION['error'] = 'Please Scan your QR CODE';
    }
    
    header("location: ../scanner.php");
    $conn-> close();
?>
<!-- TEST -->





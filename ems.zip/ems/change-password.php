
<?php 
// $email = $_SESSION['EmailId'];
// if($email == false){
//   header('Location: index.php');
// }
session_start();
include('includes/config.php');


$errors = array();
//if user click reset password button
if(isset($_POST['reset-password'])){
    $_SESSION['info'] = "";
    $password = mysqli_real_escape_string($conn, $_POST['pword']);
    $cpassword = mysqli_real_escape_string($conn, $_POST['cpword']);
    if($password !== $cpassword){
        $errors['pword'] = "Confirm password not matched!";
    }else{
        $email = $_POST['email'];
        $encpass = md5($password);
        $update_pass = "UPDATE tblemployees SET Password = '$encpass' WHERE EmailId = '$email'";
        $run_query = mysqli_query($conn, $update_pass);
        if($run_query){
            $info = "Your password changed. Now you can login with your new password.";
            $_SESSION['info'] = $info;
            header('Location: password-changed.php');
        }else{
            $errors['db-error'] = "Failed to change your password!";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Change Password</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="src/styles/fg.css">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-4 offset-md-4 form">
                <form action="change-password.php" method="POST" autocomplete="off">
                    <h2 class="text-center">Change Password</h2>
                    <?php 
                    if(isset($_SESSION['info'])){
                        ?>
                        <div class="alert alert-success text-center">
                            <?php echo $_SESSION['info']; ?>
                        </div>
                        <?php
                    }
                    ?>
                    <?php
                    if(count($errors) > 0){
                        ?>
                        <div class="alert alert-danger text-center">
                            <?php
                            foreach($errors as $showerror){
                                echo $showerror;
                            }
                            ?>
                        </div>
                        <?php
                    }
                    ?>
                    <div class="form-group">
                        <input class="form-control" type="text" name="email" placeholder="Enter your Email" required>
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="password" name="pword" placeholder="Password" required>
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="password" name="cpword" placeholder="Confirm your password" required>
                    </div>
                    <div class="form-group">
                        <input class="form-control button" type="submit" name="reset-password" value="Change">
                    </div>
                </form>
            </div>
        </div>
    </div>
    
</body>
</html>